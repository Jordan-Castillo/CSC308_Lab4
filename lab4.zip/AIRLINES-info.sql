/* -.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.-.

* File Name : AIRLINES-info.sql

* Purpose :

* Creation Date : 31-10-2017

* Last Modified : Tue 31 Oct 2017 10:52:53 PM PDT

* Created By : Jordan Castillo

* Email: jtcastil@calpoly.edu 

_._._._._._._._._._._._._._._._._._._._._.*/
--Q1)
--Q2)

--Q3)

--Q4)

--Q5)

